function UserModel () {
  this.model = data;
}
