function AppView(id){
  this.el = $('#'+ip);
  this.el.html( new BookView().el );
  сonsole.log('In debugger we trust. c !== с');
}
